//
//  MyPromotionViewController.h
//  Health
//
//  Created by admin on 2017/9/1.
//  Copyright © 2017年 com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyPromotionViewController : UIViewController

@end
