//
//  ErrorHandler.h
//  Jianshenhui
//
//  Created by ZIYAO YANG on 16/7/14.
//  Copyright © 2016年 ZIYAO YANG. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ErrorHandler : NSObject

+ (NSString *)getProperErrorString:(NSInteger)code;

@end
